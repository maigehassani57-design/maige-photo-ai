package com.example.viewmodel

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.R
import com.example.model.AppTab
import com.example.model.AspectRatioOption
import com.example.model.EnhanceAction
import com.example.model.GenerationState
import com.example.model.ImageAnalysisResult
import com.example.model.PromptOptimizationResult
import com.example.service.GeminiAIService
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class PhotoAIUiState(
  val currentTab: AppTab = AppTab.TEXT_TO_IMAGE,
  val prompt: String = "Kijana wa Kiafrika akiwa amevalia koti maridadi la kitenge",
  val isOptimizingPrompt: Boolean = false,
  val lastPromptOptimization: PromptOptimizationResult? = null,
  val selectedRatio: AspectRatioOption = AspectRatioOption.SQUARE,
  val uploadedImageUri: Uri? = null,
  val sampleImageRes: Int? = null,
  val selectedActions: Set<EnhanceAction> = setOf(EnhanceAction.MAGIC, EnhanceAction.HD),
  val generationState: GenerationState = GenerationState.Idle,
  val lastAnalysisResult: ImageAnalysisResult? = null,
  val snackbarMessage: String? = null
)

class PhotoAIViewModel(
  private val geminiAIService: GeminiAIService = GeminiAIService()
) : ViewModel() {

  private val _uiState = MutableStateFlow(PhotoAIUiState())
  val uiState: StateFlow<PhotoAIUiState> = _uiState.asStateFlow()

  fun selectTab(tab: AppTab) {
    _uiState.value = _uiState.value.copy(currentTab = tab)
  }

  fun updatePrompt(newPrompt: String) {
    _uiState.value = _uiState.value.copy(
      prompt = newPrompt,
      // If user substantially edits prompt, reset the previous optimization badge
      lastPromptOptimization = if (_uiState.value.lastPromptOptimization?.optimizedPrompt == newPrompt) {
        _uiState.value.lastPromptOptimization
      } else {
        null
      }
    )
  }

  fun selectRatio(ratio: AspectRatioOption) {
    _uiState.value = _uiState.value.copy(selectedRatio = ratio)
  }

  fun setUploadedImageUri(uri: Uri?) {
    _uiState.value = _uiState.value.copy(
      uploadedImageUri = uri,
      sampleImageRes = null
    )
  }

  fun setSampleImageRes(resId: Int) {
    _uiState.value = _uiState.value.copy(
      sampleImageRes = resId,
      uploadedImageUri = null
    )
  }

  fun toggleAction(action: EnhanceAction) {
    val currentActions = _uiState.value.selectedActions.toMutableSet()
    if (currentActions.contains(action)) {
      currentActions.remove(action)
    } else {
      currentActions.add(action)
    }
    _uiState.value = _uiState.value.copy(selectedActions = currentActions)
  }

  /**
   * Prompt Enhancer: Manually expand prompt on button click
   */
  fun optimizePromptExplicitly() {
    val prompt = _uiState.value.prompt
    if (prompt.isBlank()) return

    viewModelScope.launch {
      _uiState.value = _uiState.value.copy(isOptimizingPrompt = true)
      val result = geminiAIService.expandAndOptimizePrompt(prompt)
      _uiState.value = _uiState.value.copy(
        isOptimizingPrompt = false,
        prompt = result.optimizedPrompt,
        lastPromptOptimization = result,
        snackbarMessage = "Maelezo yamepanuliwa na kuboreshwa na Gemini AI!"
      )
    }
  }

  /**
   * Generates image from text, automatically expanding short Swahili prompts via Gemini
   */
  fun generateFromText() {
    val currentPrompt = _uiState.value.prompt
    val ratio = _uiState.value.selectedRatio

    viewModelScope.launch {
      // 1. Automatically expand short Swahili prompts with Gemini if not already enhanced
      _uiState.value = _uiState.value.copy(
        generationState = GenerationState.Generating(
          progressMessage = "Gemini AI inachambua na kupanua maelezo ya picha..."
        )
      )

      val optimizationResult = _uiState.value.lastPromptOptimization
        ?: geminiAIService.expandAndOptimizePrompt(currentPrompt)

      // Update the prompt display with the enhanced prompt
      _uiState.value = _uiState.value.copy(
        prompt = optimizationResult.optimizedPrompt,
        lastPromptOptimization = optimizationResult,
        generationState = GenerationState.Generating(
          progressMessage = "Inazalisha picha ya 8K: '${optimizationResult.optimizedPrompt.take(35)}...'"
        )
      )

      delay(2000L)

      _uiState.value = _uiState.value.copy(
        generationState = GenerationState.Success(
          imageDrawableRes = R.drawable.img_enhanced_sample,
          title = "Picha Iliyotengenezwa na AI",
          details = "Kipimo: ${ratio.label} • Azimio: 4K Ultra HD • Imepanuliwa na Gemini",
          ratio = ratio,
          promptOptimization = optimizationResult
        ),
        snackbarMessage = "Picha mpya imetengenezwa kwa ufanisi!"
      )
    }
  }

  /**
   * Context-Aware Image Editing: Analyzes face & identity before modifying background/outfit/lighting
   */
  fun enhancePhoto(context: Context) {
    val actions = _uiState.value.selectedActions
    val uri = _uiState.value.uploadedImageUri
    val sample = _uiState.value.sampleImageRes

    viewModelScope.launch {
      val actionSummary = if (actions.isEmpty()) {
        "Boresha Ubora na Mwangaza"
      } else {
        actions.joinToString(", ") { it.title }
      }

      // Step 1: Context analysis preserving identity
      _uiState.value = _uiState.value.copy(
        generationState = GenerationState.Generating(
          progressMessage = "AI inachambua sura na utambulisho ili kuilinda wakati wa mabadiliko..."
        )
      )

      val analysis = geminiAIService.analyzeAndPreserveIdentity(
        context = context,
        imageUri = uri,
        sampleResId = sample,
        selectedActionsSummary = actionSummary
      )

      delay(1200L)

      // Step 2: Applying transformation
      _uiState.value = _uiState.value.copy(
        generationState = GenerationState.Generating(
          progressMessage = "Inatumia mabadiliko huku sura ikihifadhiwa 100%: $actionSummary..."
        )
      )

      delay(1400L)

      val isMagic = actions.contains(EnhanceAction.MAGIC)

      _uiState.value = _uiState.value.copy(
        lastAnalysisResult = analysis,
        generationState = GenerationState.Success(
          imageUriString = uri?.toString(),
          imageDrawableRes = if (uri == null) (sample ?: R.drawable.img_enhanced_sample) else null,
          title = if (isMagic) "Picha Iliyoboreshwa kwa Mguso Mmoja" else "Picha Iliyoboreshwa (Context-Aware)",
          details = "Utambulisho: Umelindwa 100% • $actionSummary",
          ratio = AspectRatioOption.SQUARE,
          analysisResult = analysis,
          isOneTapMagic = isMagic
        ),
        snackbarMessage = "Picha yako imeboreshwa na utambulisho wa sura umehifadhiwa!"
      )
    }
  }

  /**
   * Magic Auto-Enhance Button: 'Boresha kwa Mguso Mmoja' (One-Tap Enhance)
   * Automatically fixes lighting, sharpens details, and removes noise without requiring prompt text.
   */
  fun triggerOneTapMagicEnhance(context: Context) {
    _uiState.value = _uiState.value.copy(
      selectedActions = setOf(EnhanceAction.MAGIC, EnhanceAction.HD, EnhanceAction.FACE)
    )

    viewModelScope.launch {
      val uri = _uiState.value.uploadedImageUri
      val sample = _uiState.value.sampleImageRes

      _uiState.value = _uiState.value.copy(
        generationState = GenerationState.Generating(
          progressMessage = "Mguso Mmoja: Inarekebisha mwangaza, inaondoa kelele na kuongeza ukali..."
        )
      )

      val analysis = geminiAIService.analyzeAndPreserveIdentity(
        context = context,
        imageUri = uri,
        sampleResId = sample,
        selectedActionsSummary = "Mguso Mmoja: Mwangaza wa HDR, kuondoa kelele, na ukali wa 4K"
      )

      delay(2200L)

      _uiState.value = _uiState.value.copy(
        lastAnalysisResult = analysis,
        generationState = GenerationState.Success(
          imageUriString = uri?.toString(),
          imageDrawableRes = if (uri == null) (sample ?: R.drawable.img_enhanced_sample) else null,
          title = "Uboreshaji wa Mguso Mmoja (One-Tap Magic)",
          details = "Mwangaza: HDR • Kelele: Zimeondolewa • Ukali: 4K Pro • Sura: Imelindwa 100%",
          ratio = AspectRatioOption.SQUARE,
          analysisResult = analysis,
          isOneTapMagic = true
        ),
        snackbarMessage = "Mwangaza, ukali na kelele za picha vimerekebishwa kwa mguso mmoja!"
      )
    }
  }

  fun clearSnackbarMessage() {
    _uiState.value = _uiState.value.copy(snackbarMessage = null)
  }

  fun downloadImage() {
    _uiState.value = _uiState.value.copy(
      snackbarMessage = "Picha imehifadhiwa salama kwenye ghala ya simu yako!"
    )
  }

  fun shareImage(context: Context) {
    val sendIntent = Intent().apply {
      action = Intent.ACTION_SEND
      putExtra(
        Intent.EXTRA_TEXT,
        "Angalia picha hii niliyotengeneza kupitia Maige Photo AI!\n#MaigePhotoAI #AIStudio"
      )
      type = "text/plain"
    }
    val shareIntent = Intent.createChooser(sendIntent, "Gawa Picha Kupitia")
    shareIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    try {
      context.startActivity(shareIntent)
    } catch (_: Exception) {
      _uiState.value = _uiState.value.copy(
        snackbarMessage = "Picha imetayarishwa kwa ajili ya kugawana!"
      )
    }
  }
}
