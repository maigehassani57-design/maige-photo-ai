package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Premium Dark Theme Palette
val ObsidianBg = Color(0xFF0D0B14)
val ObsidianSurface = Color(0xFF161224)
val ObsidianSurfaceVariant = Color(0xFF231D38)
val ObsidianCardBorder = Color(0xFF393059)

val PrimaryNeonViolet = Color(0xFFA855F7)
val PrimaryNeonVioletLight = Color(0xFFC084FC)
val PrimaryNeonVioletDark = Color(0xFF7E22CE)

val SecondaryCyan = Color(0xFF06B6D4)
val SecondaryCyanLight = Color(0xFF67E8F9)
val SecondaryCyanDark = Color(0xFF0E7490)

val TertiaryRose = Color(0xFFF43F5E)
val TertiaryRoseLight = Color(0xFFFDA4AF)

val TextPrimaryDark = Color(0xFFF8FAFC)
val TextSecondaryDark = Color(0xFF94A3B8)
val TextMutedDark = Color(0xFF64748B)

// Premium Light Theme Palette
val LightBg = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF1EEFE)
val LightPrimary = Color(0xFF7C3AED)
val LightSecondary = Color(0xFF0284C7)
val LightTertiary = Color(0xFFE11D48)
val TextPrimaryLight = Color(0xFF0F172A)
val TextSecondaryLight = Color(0xFF475569)
