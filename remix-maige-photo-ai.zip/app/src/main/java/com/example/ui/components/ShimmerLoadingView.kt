package com.example.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.PrimaryNeonViolet
import com.example.ui.theme.SecondaryCyan

@Composable
fun ShimmerBrush(): Brush {
  val transition = rememberInfiniteTransition(label = "shimmer_transition")
  val translateAnimation by transition.animateFloat(
    initialValue = 0f,
    targetValue = 1000f,
    animationSpec = infiniteRepeatable(
      animation = tween(durationMillis = 1300, easing = LinearEasing),
      repeatMode = RepeatMode.Restart
    ),
    label = "shimmer_anim"
  )

  val shimmerColors = listOf(
    Color(0xFF1E1933),
    Color(0xFF382F5A),
    Color(0xFF5E4E8F),
    Color(0xFF382F5A),
    Color(0xFF1E1933)
  )

  return Brush.linearGradient(
    colors = shimmerColors,
    start = Offset(translateAnimation - 500f, translateAnimation - 500f),
    end = Offset(translateAnimation, translateAnimation)
  )
}

@Composable
fun ShimmerLoadingCard(
  message: String,
  modifier: Modifier = Modifier
) {
  val shimmerBrush = ShimmerBrush()

  Box(
    modifier = modifier
      .fillMaxWidth()
      .height(280.dp)
      .clip(RoundedCornerShape(24.dp))
      .background(shimmerBrush)
      .border(
        width = 1.dp,
        brush = Brush.linearGradient(
          listOf(PrimaryNeonViolet.copy(alpha = 0.5f), SecondaryCyan.copy(alpha = 0.4f))
        ),
        shape = RoundedCornerShape(24.dp)
      )
      .testTag("shimmer_loading_card"),
    contentAlignment = Alignment.Center
  ) {
    Column(
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.Center,
      modifier = Modifier.padding(24.dp)
    ) {
      Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
          .size(72.dp)
          .clip(CircleShape)
          .background(Color(0xFF130F24).copy(alpha = 0.85f))
          .border(1.5.dp, PrimaryNeonViolet, CircleShape)
      ) {
        CircularProgressIndicator(
          color = SecondaryCyan,
          strokeWidth = 3.dp,
          modifier = Modifier.size(56.dp)
        )
        Icon(
          imageVector = Icons.Default.AutoAwesome,
          contentDescription = "Inatengeneza",
          tint = PrimaryNeonViolet,
          modifier = Modifier.size(28.dp)
        )
      }

      Spacer(modifier = Modifier.height(16.dp))

      Text(
        text = message,
        style = MaterialTheme.typography.titleMedium.copy(
          fontWeight = FontWeight.Bold,
          fontSize = 16.sp
        ),
        color = Color.White,
        textAlign = TextAlign.Center
      )

      Spacer(modifier = Modifier.height(6.dp))

      Text(
        text = "Inakamilisha maelezo kwa ubora wa juu...",
        style = MaterialTheme.typography.bodySmall,
        color = Color(0xFF94A3B8),
        textAlign = TextAlign.Center
      )
    }
  }
}
