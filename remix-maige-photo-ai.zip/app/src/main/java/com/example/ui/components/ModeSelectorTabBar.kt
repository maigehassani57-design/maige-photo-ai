package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AppTab
import com.example.ui.theme.PrimaryNeonViolet
import com.example.ui.theme.SecondaryCyan

@Composable
fun ModeSelectorTabBar(
  selectedTab: AppTab,
  onTabSelected: (AppTab) -> Unit,
  modifier: Modifier = Modifier
) {
  Box(
    modifier = modifier
      .fillMaxWidth()
      .padding(horizontal = 20.dp, vertical = 8.dp)
      .clip(RoundedCornerShape(18.dp))
      .background(Color(0xFF161224))
      .border(1.dp, Color(0xFF2C2447), RoundedCornerShape(18.dp))
      .padding(4.dp)
      .testTag("mode_selector_tab_bar")
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceEvenly
    ) {
      // Tab: Tengeneza Mpya (Text-to-Image)
      TabItem(
        title = "Tengeneza Mpya",
        icon = Icons.Default.AutoAwesome,
        isSelected = selectedTab == AppTab.TEXT_TO_IMAGE,
        testTag = "tab_text_to_image",
        modifier = Modifier.weight(1f),
        onClick = { onTabSelected(AppTab.TEXT_TO_IMAGE) }
      )

      Spacer(modifier = Modifier.width(6.dp))

      // Tab: Boresha Picha (Image-to-Image / Photo Enhancement)
      TabItem(
        title = "Boresha Picha",
        icon = Icons.Default.AutoFixHigh,
        isSelected = selectedTab == AppTab.IMAGE_ENHANCEMENT,
        testTag = "tab_image_enhancement",
        modifier = Modifier.weight(1f),
        onClick = { onTabSelected(AppTab.IMAGE_ENHANCEMENT) }
      )
    }
  }
}

@Composable
private fun TabItem(
  title: String,
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  isSelected: Boolean,
  testTag: String,
  modifier: Modifier = Modifier,
  onClick: () -> Unit
) {
  val bgColor by animateColorAsState(
    targetValue = if (isSelected) Color(0xFF2B1F4A) else Color.Transparent,
    animationSpec = tween(durationMillis = 200, easing = FastOutSlowInEasing),
    label = "tab_bg_color"
  )

  val textColor by animateColorAsState(
    targetValue = if (isSelected) Color.White else Color(0xFF94A3B8),
    animationSpec = tween(durationMillis = 200),
    label = "tab_text_color"
  )

  val iconTint by animateColorAsState(
    targetValue = if (isSelected) SecondaryCyan else Color(0xFF64748B),
    animationSpec = tween(durationMillis = 200),
    label = "tab_icon_tint"
  )

  Box(
    modifier = modifier
      .clip(RoundedCornerShape(14.dp))
      .background(
        if (isSelected) {
          Brush.horizontalGradient(
            listOf(Color(0xFF7E22CE), Color(0xFF4C1D95))
          )
        } else {
          Brush.linearGradient(listOf(Color.Transparent, Color.Transparent))
        }
      )
      .clickable(onClick = onClick)
      .padding(vertical = 12.dp, horizontal = 10.dp)
      .testTag(testTag),
    contentAlignment = Alignment.Center
  ) {
    Row(
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.Center
    ) {
      Icon(
        imageVector = icon,
        contentDescription = title,
        tint = if (isSelected) Color.White else iconTint,
        modifier = Modifier.size(18.dp)
      )

      Spacer(modifier = Modifier.width(8.dp))

      Text(
        text = title,
        style = MaterialTheme.typography.labelLarge.copy(
          fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
          fontSize = 13.sp
        ),
        color = if (isSelected) Color.White else textColor
      )
    }
  }
}
