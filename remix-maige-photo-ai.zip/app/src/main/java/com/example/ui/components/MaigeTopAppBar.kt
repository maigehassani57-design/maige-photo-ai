package com.example.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.PrimaryNeonViolet
import com.example.ui.theme.SecondaryCyan
import com.example.ui.theme.TertiaryRose

@Composable
fun MaigeTopAppBar(
  modifier: Modifier = Modifier
) {
  Surface(
    modifier = modifier
      .fillMaxWidth()
      .statusBarsPadding()
      .testTag("maige_top_app_bar"),
    color = Color(0xFF0F0C1B),
    tonalElevation = 6.dp
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 20.dp, vertical = 14.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically
      ) {
        // Dedicated Circular Logo Placeholder next to the title
        Box(
          modifier = Modifier
            .size(44.dp)
            .shadow(10.dp, CircleShape, spotColor = PrimaryNeonViolet)
            .clip(CircleShape)
            .background(Color(0xFF1B162C))
            .border(
              width = 2.dp,
              brush = Brush.sweepGradient(
                listOf(PrimaryNeonViolet, SecondaryCyan, TertiaryRose, PrimaryNeonViolet)
              ),
              shape = CircleShape
            )
            .testTag("circular_logo_placeholder"),
          contentAlignment = Alignment.Center
        ) {
          Image(
            painter = painterResource(id = R.drawable.img_app_logo),
            contentDescription = "Nembo ya Maige Photo AI",
            contentScale = ContentScale.Crop,
            modifier = Modifier.size(40.dp).clip(CircleShape)
          )
        }

        Spacer(modifier = Modifier.width(14.dp))

        Column {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
              text = "Maige Photo AI",
              style = MaterialTheme.typography.titleLarge.copy(
                fontWeight = FontWeight.Black,
                fontSize = 20.sp,
                letterSpacing = (-0.5).sp
              ),
              color = Color.White
            )
            Spacer(modifier = Modifier.width(6.dp))
            Icon(
              imageVector = Icons.Default.AutoAwesome,
              contentDescription = "AI Powered",
              tint = SecondaryCyan,
              modifier = Modifier.size(16.dp)
            )
          }

          Text(
            text = "Studio ya Picha ya Kisasa",
            style = MaterialTheme.typography.bodySmall.copy(
              fontSize = 11.sp,
              fontWeight = FontWeight.Medium
            ),
            color = Color(0xFF94A3B8)
          )
        }
      }

      // Premium Badge Indicator
      Box(
        modifier = Modifier
          .clip(RoundedCornerShape(20.dp))
          .background(
            Brush.horizontalGradient(
              listOf(Color(0xFF7E22CE).copy(alpha = 0.4f), Color(0xFF0E7490).copy(alpha = 0.4f))
            )
          )
          .border(
            width = 1.dp,
            brush = Brush.horizontalGradient(listOf(PrimaryNeonViolet, SecondaryCyan)),
            shape = RoundedCornerShape(20.dp)
          )
          .padding(horizontal = 10.dp, vertical = 5.dp)
      ) {
        Text(
          text = "PRO AI",
          style = MaterialTheme.typography.labelSmall.copy(
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp,
            fontSize = 10.sp
          ),
          color = Color(0xFFE2E8F0)
        )
      }
    }
  }
}
