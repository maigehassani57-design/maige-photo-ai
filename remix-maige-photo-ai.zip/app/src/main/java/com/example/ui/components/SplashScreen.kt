package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.PrimaryNeonViolet
import com.example.ui.theme.SecondaryCyan
import com.example.ui.theme.TertiaryRose
import kotlinx.coroutines.delay

@Composable
fun SplashScreen(
  onTimeout: () -> Unit,
  modifier: Modifier = Modifier
) {
  // Exactly 2-second duration for the sleek splash screen
  LaunchedEffect(Unit) {
    delay(2000L)
    onTimeout()
  }

  val infiniteTransition = rememberInfiniteTransition(label = "splash_glow")
  val pulseScale by infiniteTransition.animateFloat(
    initialValue = 0.96f,
    targetValue = 1.05f,
    animationSpec = infiniteRepeatable(
      animation = tween(1000, easing = FastOutSlowInEasing),
      repeatMode = RepeatMode.Reverse
    ),
    label = "pulse_scale"
  )

  val glowAlpha by infiniteTransition.animateFloat(
    initialValue = 0.35f,
    targetValue = 0.85f,
    animationSpec = infiniteRepeatable(
      animation = tween(1000, easing = FastOutSlowInEasing),
      repeatMode = RepeatMode.Reverse
    ),
    label = "glow_alpha"
  )

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(
        Brush.radialGradient(
          colors = listOf(
            Color(0xFF261D42),
            Color(0xFF130F24),
            ObsidianBg
          )
        )
      )
      .clickable { onTimeout() } // Tap to skip if needed
      .testTag("splash_screen"),
    contentAlignment = Alignment.Center
  ) {
    Column(
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.Center,
      modifier = Modifier.padding(32.dp)
    ) {
      // Sleek Logo Placeholder with Animated Glowing Ring
      Box(
        modifier = Modifier
          .size(136.dp)
          .scale(pulseScale),
        contentAlignment = Alignment.Center
      ) {
        // Outer Glow Aura
        Box(
          modifier = Modifier
            .size(136.dp)
            .clip(CircleShape)
            .background(
              Brush.radialGradient(
                colors = listOf(
                  PrimaryNeonViolet.copy(alpha = glowAlpha),
                  SecondaryCyan.copy(alpha = glowAlpha * 0.5f),
                  Color.Transparent
                )
              )
            )
        )

        // Logo Container
        Box(
          modifier = Modifier
            .size(112.dp)
            .shadow(24.dp, CircleShape, spotColor = PrimaryNeonViolet)
            .clip(CircleShape)
            .background(Color(0xFF16112C))
            .border(
              width = 3.dp,
              brush = Brush.sweepGradient(
                listOf(PrimaryNeonViolet, SecondaryCyan, TertiaryRose, PrimaryNeonViolet)
              ),
              shape = CircleShape
            )
            .testTag("splash_logo_placeholder"),
          contentAlignment = Alignment.Center
        ) {
          Image(
            painter = painterResource(id = R.drawable.img_app_logo),
            contentDescription = "Nembo ya Maige Photo AI",
            contentScale = ContentScale.Crop,
            modifier = Modifier.size(104.dp).clip(CircleShape)
          )
        }
      }

      Spacer(modifier = Modifier.height(32.dp))

      // App Title
      Row(
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = "Maige Photo AI",
          style = MaterialTheme.typography.headlineMedium.copy(
            fontWeight = FontWeight.Black,
            fontSize = 30.sp,
            letterSpacing = (-0.5).sp
          ),
          color = Color.White
        )
        Spacer(modifier = Modifier.width(8.dp))
        Icon(
          imageVector = Icons.Default.AutoAwesome,
          contentDescription = null,
          tint = SecondaryCyan,
          modifier = Modifier.size(24.dp)
        )
      }

      Spacer(modifier = Modifier.height(10.dp))

      // Tagline in Kiswahili
      Text(
        text = "Uzalishaji & Uboreshaji wa Picha wa Kisasa",
        style = MaterialTheme.typography.bodyMedium.copy(
          fontSize = 14.sp,
          fontWeight = FontWeight.Medium
        ),
        color = Color(0xFFCBD5E1),
        textAlign = TextAlign.Center
      )

      Spacer(modifier = Modifier.height(48.dp))

      // Subtle loading spinner
      CircularProgressIndicator(
        modifier = Modifier.size(32.dp),
        color = SecondaryCyan,
        strokeWidth = 3.dp,
        trackColor = Color(0xFF2A2247)
      )

      Spacer(modifier = Modifier.height(14.dp))

      Text(
        text = "Inapakia mfumo wa AI...",
        style = MaterialTheme.typography.labelMedium,
        color = Color(0xFF94A3B8)
      )
    }
  }
}
