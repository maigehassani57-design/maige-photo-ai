package com.example.ui

import android.content.Context
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.model.AppTab
import com.example.model.GenerationState
import com.example.ui.components.ImageEnhancementTab
import com.example.ui.components.MaigeTopAppBar
import com.example.ui.components.ModeSelectorTabBar
import com.example.ui.components.OutputShowcaseArea
import com.example.ui.components.TextToImageTab
import com.example.ui.theme.ObsidianBg
import com.example.viewmodel.PhotoAIViewModel

@Composable
fun MainScreen(
  viewModel: PhotoAIViewModel = viewModel(),
  modifier: Modifier = Modifier
) {
  val uiState by viewModel.uiState.collectAsState()
  val scrollState = rememberScrollState()
  val snackbarHostState = remember { SnackbarHostState() }
  val context = LocalContext.current

  LaunchedEffect(uiState.snackbarMessage) {
    uiState.snackbarMessage?.let { message ->
      snackbarHostState.showSnackbar(message)
      viewModel.clearSnackbarMessage()
    }
  }

  Scaffold(
    modifier = modifier.fillMaxSize(),
    topBar = {
      MaigeTopAppBar()
    },
    snackbarHost = {
      SnackbarHost(
        hostState = snackbarHostState,
        modifier = Modifier.navigationBarsPadding()
      )
    },
    containerColor = ObsidianBg
  ) { innerPadding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
        .verticalScroll(scrollState)
        .navigationBarsPadding()
    ) {
      Spacer(modifier = Modifier.height(6.dp))

      // Mode Selector (Tab Bar): 'Tengeneza Mpya' & 'Boresha Picha'
      ModeSelectorTabBar(
        selectedTab = uiState.currentTab,
        onTabSelected = { tab -> viewModel.selectTab(tab) }
      )

      // Dynamic Tab Content
      AnimatedContent(
        targetState = uiState.currentTab,
        transitionSpec = { fadeIn() togetherWith fadeOut() },
        label = "tab_content_transition"
      ) { tab ->
        when (tab) {
          AppTab.TEXT_TO_IMAGE -> {
            TextToImageTab(
              prompt = uiState.prompt,
              onPromptChange = { viewModel.updatePrompt(it) },
              selectedRatio = uiState.selectedRatio,
              onRatioSelected = { viewModel.selectRatio(it) },
              onGenerateClick = { viewModel.generateFromText() },
              isGenerating = uiState.generationState is GenerationState.Generating,
              onOptimizePromptClick = { viewModel.optimizePromptExplicitly() },
              isOptimizingPrompt = uiState.isOptimizingPrompt,
              lastPromptOptimization = uiState.lastPromptOptimization
            )
          }

          AppTab.IMAGE_ENHANCEMENT -> {
            ImageEnhancementTab(
              selectedImageUri = uiState.uploadedImageUri,
              sampleImageRes = uiState.sampleImageRes,
              onImageSelected = { uri -> viewModel.setUploadedImageUri(uri) },
              onSampleSelected = { resId -> viewModel.setSampleImageRes(resId) },
              selectedActions = uiState.selectedActions,
              onToggleAction = { action -> viewModel.toggleAction(action) },
              onEnhanceClick = { viewModel.enhancePhoto(context) },
              onOneTapMagicClick = { viewModel.triggerOneTapMagicEnhance(context) },
              isGenerating = uiState.generationState is GenerationState.Generating
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      // Output & Showcase Area
      OutputShowcaseArea(
        generationState = uiState.generationState,
        onDownloadClick = { viewModel.downloadImage() },
        onShareClick = { viewModel.shareImage(context) }
      )

      Spacer(modifier = Modifier.height(30.dp))
    }
  }
}
