package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Maige Photo AI", appName)
  }

  @Test
  fun `verify magic auto-enhance chip string exists`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val magicAction = context.getString(R.string.quick_action_magic)
    assertEquals("Boresha kwa Mguso Mmoja", magicAction)
  }

  @Test
  fun `verify prompt enhancer expands swahili prompt`() {
    val service = com.example.service.GeminiAIService()
    kotlinx.coroutines.runBlocking {
      val result = service.expandAndOptimizePrompt("kijana wa kitanzania ufukweni")
      org.junit.Assert.assertTrue(result.isOptimized)
      org.junit.Assert.assertTrue(result.optimizedPrompt.isNotBlank())
      org.junit.Assert.assertTrue(result.optimizedPrompt.length > "kijana wa kitanzania ufukweni".length)
    }
  }

  @Test
  fun `verify context-aware image editing preserves facial identity`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val service = com.example.service.GeminiAIService()
    kotlinx.coroutines.runBlocking {
      val result = service.analyzeAndPreserveIdentity(
        context = context,
        imageUri = null,
        sampleResId = R.drawable.img_enhanced_sample,
        selectedActionsSummary = "Badilisha Background, Boresha Nguo"
      )
      org.junit.Assert.assertTrue(result.faceIdentityPreserved)
      org.junit.Assert.assertTrue(result.detectedFeatures.isNotEmpty())
    }
  }
}
