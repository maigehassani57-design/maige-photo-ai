package com.example.ui.components

import android.content.Context
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.R
import com.example.model.AspectRatioOption
import com.example.model.GenerationState
import com.example.ui.theme.PrimaryNeonViolet
import com.example.ui.theme.SecondaryCyan

@Composable
fun OutputShowcaseArea(
  generationState: GenerationState,
  onDownloadClick: () -> Unit,
  onShareClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  Column(
    modifier = modifier
      .fillMaxWidth()
      .padding(horizontal = 20.dp, vertical = 12.dp)
      .testTag("output_showcase_area")
  ) {
    // Header for Output Area
    Row(
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween,
      modifier = Modifier
        .fillMaxWidth()
        .padding(bottom = 12.dp)
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
          imageVector = Icons.Default.AutoAwesome,
          contentDescription = null,
          tint = SecondaryCyan,
          modifier = Modifier.size(18.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = "Matokeo ya Picha (Output)",
          style = MaterialTheme.typography.titleMedium.copy(
            fontWeight = FontWeight.Bold,
            fontSize = 17.sp
          ),
          color = Color.White
        )
      }

      if (generationState is GenerationState.Success) {
        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFF1E1535))
            .border(1.dp, SecondaryCyan.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp)
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Default.CheckCircle,
              contentDescription = null,
              tint = SecondaryCyan,
              modifier = Modifier.size(12.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
              text = if (generationState.isOneTapMagic) "Mguso Mmoja" else "Imekamilika",
              style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp),
              color = SecondaryCyan
            )
          }
        }
      }
    }

    when (generationState) {
      is GenerationState.Generating -> {
        ShimmerLoadingCard(
          message = generationState.progressMessage,
          modifier = Modifier.fillMaxWidth()
        )
      }

      is GenerationState.Success -> {
        ResultImageCard(
          state = generationState,
          onDownloadClick = onDownloadClick,
          onShareClick = onShareClick
        )
      }

      is GenerationState.Idle -> {
        IdleShowcaseCard()
      }

      is GenerationState.Error -> {
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(Color(0xFF26121E))
            .border(1.dp, Color(0xFFE11D48), RoundedCornerShape(20.dp))
            .padding(24.dp),
          contentAlignment = Alignment.Center
        ) {
          Text(
            text = generationState.message,
            color = Color(0xFFFDA4AF),
            style = MaterialTheme.typography.bodyMedium
          )
        }
      }
    }
  }
}

@Composable
private fun ResultImageCard(
  state: GenerationState.Success,
  onDownloadClick: () -> Unit,
  onShareClick: () -> Unit
) {
  Column(
    modifier = Modifier
      .fillMaxWidth()
      .testTag("result_showcase_card")
  ) {
    // Card with Image
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .shadow(20.dp, RoundedCornerShape(24.dp), spotColor = PrimaryNeonViolet)
        .clip(RoundedCornerShape(24.dp))
        .background(Color(0xFF140F22))
        .border(
          width = 2.dp,
          brush = Brush.linearGradient(
            listOf(PrimaryNeonViolet, SecondaryCyan)
          ),
          shape = RoundedCornerShape(24.dp)
        )
    ) {
      val targetRatio = when (state.ratio) {
        AspectRatioOption.SQUARE -> 1f
        AspectRatioOption.STORY -> 9f / 16f
        AspectRatioOption.LANDSCAPE -> 16f / 9f
      }

      Box(
        modifier = Modifier
          .fillMaxWidth()
          .aspectRatio(targetRatio)
          .clip(RoundedCornerShape(22.dp)),
        contentAlignment = Alignment.Center
      ) {
        if (state.imageUriString != null) {
          AsyncImage(
            model = state.imageUriString,
            contentDescription = state.title,
            modifier = Modifier.fillMaxWidth(),
            contentScale = ContentScale.Crop
          )
        } else if (state.imageDrawableRes != null) {
          Image(
            painter = painterResource(id = state.imageDrawableRes),
            contentDescription = state.title,
            modifier = Modifier.fillMaxWidth(),
            contentScale = ContentScale.Crop
          )
        } else {
          Image(
            painter = painterResource(id = R.drawable.img_enhanced_sample),
            contentDescription = state.title,
            modifier = Modifier.fillMaxWidth(),
            contentScale = ContentScale.Crop
          )
        }

        // Overlay info badge at the bottom of the image
        Box(
          modifier = Modifier
            .align(Alignment.BottomStart)
            .fillMaxWidth()
            .background(
              Brush.verticalGradient(
                listOf(Color.Transparent, Color(0xCC090714), Color(0xF0090714))
              )
            )
            .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
          Column {
            Text(
              text = state.title,
              style = MaterialTheme.typography.titleSmall.copy(
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
              ),
              color = Color.White
            )
            Text(
              text = state.details,
              style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
              color = Color(0xFFCBD5E1)
            )
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(14.dp))

    // Context-Aware Identity Preservation Report
    if (state.analysisResult != null) {
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(16.dp))
          .background(Color(0xFF121A33))
          .border(1.dp, Color(0xFF2563EB).copy(alpha = 0.5f), RoundedCornerShape(16.dp))
          .padding(14.dp)
          .testTag("identity_preservation_report")
      ) {
        Column {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = Icons.Default.VerifiedUser,
                contentDescription = null,
                tint = Color(0xFF38BDF8),
                modifier = Modifier.size(16.dp)
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = "Ripoti ya Utambulisho na Sura (Identity Lock)",
                style = MaterialTheme.typography.labelMedium.copy(
                  fontWeight = FontWeight.Bold,
                  fontSize = 12.sp
                ),
                color = Color(0xFF38BDF8)
              )
            }

            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0xFF1E3A8A))
                .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
              Text(
                text = "100% Imelindwa",
                style = MaterialTheme.typography.labelSmall.copy(
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Bold
                ),
                color = Color.White
              )
            }
          }

          Spacer(modifier = Modifier.height(8.dp))

          // Key metrics
          Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
          ) {
            Box(
              modifier = Modifier
                .weight(1f)
                .clip(RoundedCornerShape(10.dp))
                .background(Color(0xFF1E293B))
                .padding(8.dp)
            ) {
              Column {
                Text(
                  text = "Mwangaza",
                  style = MaterialTheme.typography.bodySmall.copy(fontSize = 10.sp),
                  color = Color(0xFF94A3B8)
                )
                Text(
                  text = "Dynamic HDR",
                  style = MaterialTheme.typography.labelSmall.copy(
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                  ),
                  color = Color.White
                )
              }
            }

            Box(
              modifier = Modifier
                .weight(1f)
                .clip(RoundedCornerShape(10.dp))
                .background(Color(0xFF1E293B))
                .padding(8.dp)
            ) {
              Column {
                Text(
                  text = "Ukali & Kelele",
                  style = MaterialTheme.typography.bodySmall.copy(fontSize = 10.sp),
                  color = Color(0xFF94A3B8)
                )
                Text(
                  text = "Denoised 4K",
                  style = MaterialTheme.typography.labelSmall.copy(
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                  ),
                  color = Color.White
                )
              }
            }
          }

          Spacer(modifier = Modifier.height(6.dp))

          Text(
            text = state.analysisResult.editingSummary,
            style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
            color = Color(0xFFCBD5E1)
          )
        }
      }
      Spacer(modifier = Modifier.height(14.dp))
    }

    // Prompt Optimization Breakdown (When generated from text)
    if (state.promptOptimization != null && state.promptOptimization.isOptimized) {
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(16.dp))
          .background(Color(0xFF1D1438))
          .border(1.dp, PrimaryNeonViolet.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
          .padding(14.dp)
          .testTag("prompt_optimization_report")
      ) {
        Column {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Default.AutoAwesome,
              contentDescription = null,
              tint = PrimaryNeonViolet,
              modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = "Maelezo Yaliyopanuliwa na Gemini AI",
              style = MaterialTheme.typography.labelMedium.copy(
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp
              ),
              color = Color.White
            )
          }

          Spacer(modifier = Modifier.height(6.dp))

          Text(
            text = "Asili: \"${state.promptOptimization.originalPrompt}\"",
            style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
            color = Color(0xFF94A3B8)
          )

          Spacer(modifier = Modifier.height(4.dp))

          Text(
            text = "AI Expanded: ${state.promptOptimization.optimizedPrompt}",
            style = MaterialTheme.typography.bodySmall.copy(
              fontSize = 11.sp,
              fontWeight = FontWeight.Medium
            ),
            color = Color(0xFFE2E8F0)
          )
        }
      }
      Spacer(modifier = Modifier.height(14.dp))
    }

    // Dual Action Buttons Below Image:
    // 'Hifadhi kwenye Simu' (Download) and 'Gawa' (Share)
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
      // 1. 'Hifadhi kwenye Simu' (Download)
      Button(
        onClick = onDownloadClick,
        modifier = Modifier
          .weight(1f)
          .height(50.dp)
          .clip(RoundedCornerShape(14.dp))
          .testTag("btn_download_image"),
        colors = ButtonDefaults.buttonColors(
          containerColor = Color.Transparent
        ),
        contentPadding = androidx.compose.foundation.layout.PaddingValues()
      ) {
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .height(50.dp)
            .background(
              Brush.horizontalGradient(
                listOf(Color(0xFF7C3AED), Color(0xFF4F46E5))
              )
            ),
          contentAlignment = Alignment.Center
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
          ) {
            Icon(
              imageVector = Icons.Default.Download,
              contentDescription = "Hifadhi",
              tint = Color.White,
              modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "Hifadhi kwenye Simu",
              style = MaterialTheme.typography.labelMedium.copy(
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp
              ),
              color = Color.White
            )
          }
        }
      }

      // 2. 'Gawa' (Share)
      OutlinedButton(
        onClick = onShareClick,
        modifier = Modifier
          .weight(1f)
          .height(50.dp)
          .clip(RoundedCornerShape(14.dp))
          .border(
            width = 1.5.dp,
            brush = Brush.horizontalGradient(
              listOf(SecondaryCyan, PrimaryNeonViolet)
            ),
            shape = RoundedCornerShape(14.dp)
          )
          .testTag("btn_share_image"),
        colors = ButtonDefaults.outlinedButtonColors(
          containerColor = Color(0xFF19132E)
        )
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.Center
        ) {
          Icon(
            imageVector = Icons.Default.Share,
            contentDescription = "Gawa",
            tint = SecondaryCyan,
            modifier = Modifier.size(18.dp)
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "Gawa",
            style = MaterialTheme.typography.labelMedium.copy(
              fontWeight = FontWeight.Bold,
              fontSize = 14.sp
            ),
            color = Color.White
          )
        }
      }
    }
  }
}

@Composable
private fun IdleShowcaseCard() {
  Box(
    modifier = Modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(20.dp))
      .background(Color(0xFF140F22))
      .border(1.dp, Color(0xFF2B2342), RoundedCornerShape(20.dp))
      .padding(24.dp)
      .testTag("idle_showcase_card"),
    contentAlignment = Alignment.Center
  ) {
    Column(
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.Center
    ) {
      Box(
        modifier = Modifier
          .size(56.dp)
          .clip(CircleShape)
          .background(Color(0xFF221A38)),
        contentAlignment = Alignment.Center
      ) {
        Icon(
          imageVector = Icons.Default.Image,
          contentDescription = null,
          tint = PrimaryNeonViolet,
          modifier = Modifier.size(28.dp)
        )
      }

      Spacer(modifier = Modifier.height(14.dp))

      Text(
        text = "Picha Yako Itaonekana Hapa",
        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
        color = Color.White
      )

      Spacer(modifier = Modifier.height(4.dp))

      Text(
        text = "Tumia vichupo hapo juu kutengeneza picha mpya au kuboresha iliyopo kwa akili mnemba ya Gemini",
        style = MaterialTheme.typography.bodySmall,
        color = Color(0xFF94A3B8),
        textAlign = androidx.compose.ui.text.style.TextAlign.Center
      )
    }
  }
}
