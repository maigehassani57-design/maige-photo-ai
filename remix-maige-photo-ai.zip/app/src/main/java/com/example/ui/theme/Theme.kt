package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
  primary = PrimaryNeonVioletLight,
  onPrimary = Color(0xFF1E0A3C),
  primaryContainer = PrimaryNeonVioletDark,
  onPrimaryContainer = Color(0xFFF3E8FF),
  secondary = SecondaryCyanLight,
  onSecondary = Color(0xFF00363F),
  secondaryContainer = SecondaryCyanDark,
  onSecondaryContainer = Color(0xFFCFFAFE),
  tertiary = TertiaryRoseLight,
  onTertiary = Color(0xFF4C0519),
  background = ObsidianBg,
  onBackground = TextPrimaryDark,
  surface = ObsidianSurface,
  onSurface = TextPrimaryDark,
  surfaceVariant = ObsidianSurfaceVariant,
  onSurfaceVariant = TextSecondaryDark,
  outline = ObsidianCardBorder
)

private val LightColorScheme = lightColorScheme(
  primary = LightPrimary,
  onPrimary = Color.White,
  primaryContainer = Color(0xFFE9D5FF),
  onPrimaryContainer = Color(0xFF3B0764),
  secondary = LightSecondary,
  onSecondary = Color.White,
  secondaryContainer = Color(0xFFBAE6FD),
  onSecondaryContainer = Color(0xFF082F49),
  tertiary = LightTertiary,
  onTertiary = Color.White,
  background = LightBg,
  onBackground = TextPrimaryLight,
  surface = LightSurface,
  onSurface = TextPrimaryLight,
  surfaceVariant = LightSurfaceVariant,
  onSurfaceVariant = TextSecondaryLight,
  outline = Color(0xFFCBD5E1)
)

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = true, // Default to stunning dark luxury studio mode
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit
) {
  val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

  MaterialTheme(
    colorScheme = colorScheme,
    typography = Typography,
    content = content
  )
}
