package com.example.model

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.HighQuality
import androidx.compose.material.icons.filled.Landscape
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Style
import androidx.compose.material.icons.filled.Wallpaper
import androidx.compose.material.icons.filled.CropSquare
import androidx.compose.ui.graphics.vector.ImageVector

enum class AppTab(val title: String) {
  TEXT_TO_IMAGE("Tengeneza Mpya"),
  IMAGE_ENHANCEMENT("Boresha Picha")
}

enum class AspectRatioOption(
  val id: String,
  val label: String,
  val subLabel: String,
  val ratio: Float,
  val icon: ImageVector
) {
  SQUARE("1:1", "1:1", "Mraba", 1f, Icons.Default.CropSquare),
  STORY("9:16", "9:16", "Story / TikTok", 9f / 16f, Icons.Default.PhoneAndroid),
  LANDSCAPE("16:9", "16:9", "Mlalo", 16f / 9f, Icons.Default.Landscape)
}

enum class EnhanceAction(
  val id: String,
  val title: String,
  val icon: ImageVector,
  val description: String,
  val isPrimaryMagic: Boolean = false
) {
  MAGIC(
    "magic",
    "Boresha kwa Mguso Mmoja",
    Icons.Default.AutoAwesome,
    "Rekebisha mwangaza, ongeza ukali na ondoa kelele za picha moja kwa moja bila kuandika maelezo",
    isPrimaryMagic = true
  ),
  HD(
    "hd",
    "Boresha Ubora (HD)",
    Icons.Default.HighQuality,
    "Ongeza ufasaha na ukali wa picha hadi 4K"
  ),
  BACKGROUND(
    "background",
    "Badilisha Background",
    Icons.Default.Wallpaper,
    "Ondoa au badilisha mandhari ya nyuma ya picha"
  ),
  FACE(
    "face",
    "Nyoosha Sura",
    Icons.Default.Face,
    "Lainisha ngozi, ng'arisha macho na nyoosha tabasamu"
  ),
  CLOTHES(
    "clothes",
    "Boresha Nguo",
    Icons.Default.Style,
    "Rekebisha rangi na muonekano wa mavazi"
  )
}

data class PromptOptimizationResult(
  val originalPrompt: String,
  val optimizedPrompt: String,
  val isOptimized: Boolean,
  val addedHighlights: List<String> = emptyList()
)

data class ImageAnalysisResult(
  val faceIdentityPreserved: Boolean = true,
  val detectedFeatures: List<String> = listOf("Muundo wa Sura", "Macho & Tabasamu", "Rangi ya Ngozi"),
  val lightingAdjustment: String = "Mwangaza Uliosawazishwa (Dynamic Range HDR)",
  val denoiseStatus: String = "Kelele za picha zimeondolewa kikamilifu",
  val editingSummary: String = "Sura na utambulisho wa mtu vimehifadhiwa 100% huku mandhari na ubora vikiboreshwa."
)

sealed interface GenerationState {
  data object Idle : GenerationState
  data class Generating(val progressMessage: String) : GenerationState
  data class Success(
    val imageDrawableRes: Int? = null,
    val imageUriString: String? = null,
    val title: String,
    val details: String,
    val ratio: AspectRatioOption = AspectRatioOption.SQUARE,
    val promptOptimization: PromptOptimizationResult? = null,
    val analysisResult: ImageAnalysisResult? = null,
    val isOneTapMagic: Boolean = false
  ) : GenerationState
  data class Error(val message: String) : GenerationState
}
