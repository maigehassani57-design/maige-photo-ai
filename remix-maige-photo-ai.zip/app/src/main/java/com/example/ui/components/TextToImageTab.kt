package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AspectRatioOption
import com.example.model.PromptOptimizationResult
import com.example.ui.theme.PrimaryNeonViolet
import com.example.ui.theme.SecondaryCyan

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun TextToImageTab(
  prompt: String,
  onPromptChange: (String) -> Unit,
  selectedRatio: AspectRatioOption,
  onRatioSelected: (AspectRatioOption) -> Unit,
  onGenerateClick: () -> Unit,
  isGenerating: Boolean,
  onOptimizePromptClick: () -> Unit,
  isOptimizingPrompt: Boolean,
  lastPromptOptimization: PromptOptimizationResult?,
  modifier: Modifier = Modifier
) {
  val inspirationPrompts = listOf(
    "Mwanamitindo jijini Zanzibar wakati wa jioni, mwangaza wa sinema",
    "Simba mwenye heshima katika mbuga ya Serengeti, 8K HD",
    "Gari la umeme la siku za usoni likipita usiku kwenye mvua ya neon",
    "Picha nzuri ya Mlima Kilimanjaro na theluji inayong'aa"
  )

  Column(
    modifier = modifier
      .fillMaxWidth()
      .padding(horizontal = 20.dp, vertical = 10.dp)
      .testTag("text_to_image_tab")
  ) {
    // Header for Prompt Section with Gemini AI Prompt Enhancer Action
    Row(
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween,
      modifier = Modifier
        .fillMaxWidth()
        .padding(bottom = 8.dp)
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
          imageVector = Icons.Default.AutoAwesome,
          contentDescription = null,
          tint = PrimaryNeonViolet,
          modifier = Modifier.size(18.dp)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
          text = "Maelezo ya Picha (Prompt)",
          style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
          color = Color.White
        )
      }

      // Prompt Enhancer Button: Powered by Gemini
      Box(
        modifier = Modifier
          .clip(RoundedCornerShape(20.dp))
          .background(
            if (prompt.isNotBlank() && !isOptimizingPrompt) {
              Brush.horizontalGradient(listOf(Color(0xFF6B21A8), Color(0xFF0E7490)))
            } else {
              Brush.linearGradient(listOf(Color(0xFF261D3A), Color(0xFF1E1730)))
            }
          )
          .border(
            width = 1.dp,
            color = if (prompt.isNotBlank()) SecondaryCyan.copy(alpha = 0.8f) else Color(0xFF3B2F5C),
            shape = RoundedCornerShape(20.dp)
          )
          .clickable(
            enabled = prompt.isNotBlank() && !isOptimizingPrompt,
            onClick = onOptimizePromptClick
          )
          .padding(horizontal = 10.dp, vertical = 6.dp)
          .testTag("btn_enhance_prompt_gemini")
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          if (isOptimizingPrompt) {
            CircularProgressIndicator(
              modifier = Modifier.size(12.dp),
              strokeWidth = 1.5.dp,
              color = Color.White
            )
          } else {
            Icon(
              imageVector = Icons.Default.AutoAwesome,
              contentDescription = "Gemini",
              tint = if (prompt.isNotBlank()) SecondaryCyan else Color(0xFF94A3B8),
              modifier = Modifier.size(13.dp)
            )
          }
          Spacer(modifier = Modifier.width(5.dp))
          Text(
            text = if (isOptimizingPrompt) "Inaboresha..." else "Boresha na Gemini",
            style = MaterialTheme.typography.labelSmall.copy(
              fontWeight = FontWeight.Bold,
              fontSize = 11.sp
            ),
            color = if (prompt.isNotBlank()) Color.White else Color(0xFF94A3B8)
          )
        }
      }
    }

    // Prompt Input Field with Swahili Placeholder
    OutlinedTextField(
      value = prompt,
      onValueChange = onPromptChange,
      modifier = Modifier
        .fillMaxWidth()
        .height(115.dp)
        .testTag("prompt_input_field"),
      placeholder = {
        Text(
          text = "Andika maelezo ya picha unayotaka (mfano: mwanamitindo wa Kiafrika)...",
          color = Color(0xFF64748B),
          style = MaterialTheme.typography.bodyMedium
        )
      },
      trailingIcon = {
        if (prompt.isNotEmpty()) {
          IconButton(onClick = { onPromptChange("") }) {
            Icon(
              imageVector = Icons.Default.Clear,
              contentDescription = "Futa",
              tint = Color(0xFF94A3B8)
            )
          }
        }
      },
      shape = RoundedCornerShape(16.dp),
      colors = OutlinedTextFieldDefaults.colors(
        focusedContainerColor = Color(0xFF161224),
        unfocusedContainerColor = Color(0xFF130F20),
        focusedBorderColor = PrimaryNeonViolet,
        unfocusedBorderColor = Color(0xFF2B2344),
        focusedTextColor = Color.White,
        unfocusedTextColor = Color.White
      )
    )

    // Animated Badge showing Gemini prompt optimization details
    AnimatedVisibility(
      visible = lastPromptOptimization != null && lastPromptOptimization.isOptimized,
      enter = fadeIn(),
      exit = fadeOut()
    ) {
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .padding(top = 8.dp)
          .clip(RoundedCornerShape(12.dp))
          .background(Color(0xFF1D1438))
          .border(1.dp, PrimaryNeonViolet.copy(alpha = 0.6f), RoundedCornerShape(12.dp))
          .padding(10.dp)
      ) {
        Column {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Default.CheckCircle,
              contentDescription = null,
              tint = SecondaryCyan,
              modifier = Modifier.size(14.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = "Imepanuliwa na Gemini AI kuwa viwango vya Studio 8K",
              style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp
              ),
              color = SecondaryCyan
            )
          }

          if (lastPromptOptimization?.addedHighlights?.isNotEmpty() == true) {
            Spacer(modifier = Modifier.height(4.dp))
            Row(
              horizontalArrangement = Arrangement.spacedBy(6.dp),
              modifier = Modifier.fillMaxWidth()
            ) {
              lastPromptOptimization.addedHighlights.take(2).forEach { highlight ->
                Box(
                  modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color(0xFF291B4C))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                  Text(
                    text = highlight,
                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 10.sp),
                    color = Color(0xFFCBD5E1)
                  )
                }
              }
            }
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(10.dp))

    // Quick Inspiration Chips in Kiswahili
    Row(
      verticalAlignment = Alignment.CenterVertically,
      modifier = Modifier.padding(vertical = 4.dp)
    ) {
      Icon(
        imageVector = Icons.Default.Lightbulb,
        contentDescription = null,
        tint = SecondaryCyan,
        modifier = Modifier.size(14.dp)
      )
      Spacer(modifier = Modifier.width(4.dp))
      Text(
        text = "Mifano ya haraka:",
        style = MaterialTheme.typography.labelSmall,
        color = Color(0xFF94A3B8)
      )
    }

    FlowRow(
      horizontalArrangement = Arrangement.spacedBy(8.dp),
      verticalArrangement = Arrangement.spacedBy(6.dp),
      modifier = Modifier.fillMaxWidth()
    ) {
      inspirationPrompts.forEachIndexed { index, suggestion ->
        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFF1C1730))
            .border(1.dp, Color(0xFF332952), RoundedCornerShape(12.dp))
            .clickable { onPromptChange(suggestion) }
            .padding(horizontal = 10.dp, vertical = 6.dp)
            .testTag("prompt_suggestion_$index")
        ) {
          Text(
            text = suggestion.take(30) + if (suggestion.length > 30) "..." else "",
            style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
            color = Color(0xFFCBD5E1)
          )
        }
      }
    }

    Spacer(modifier = Modifier.height(18.dp))

    // Aspect Ratio Selector Header
    Text(
      text = "Kipimo cha Picha (Aspect Ratio)",
      style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
      color = Color.White,
      modifier = Modifier.padding(bottom = 10.dp)
    )

    // Aspect Ratio Cards with Visual Icons
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
      AspectRatioOption.entries.forEach { option ->
        val isSelected = selectedRatio == option
        AspectRatioCard(
          option = option,
          isSelected = isSelected,
          modifier = Modifier.weight(1f),
          onClick = { onRatioSelected(option) }
        )
      }
    }

    Spacer(modifier = Modifier.height(20.dp))

    // Action Button: "Tengeneza Sasa (Gemini Enhanced)"
    Button(
      onClick = onGenerateClick,
      enabled = prompt.isNotBlank() && !isGenerating,
      modifier = Modifier
        .fillMaxWidth()
        .height(52.dp)
        .clip(RoundedCornerShape(16.dp))
        .testTag("btn_generate_image"),
      colors = ButtonDefaults.buttonColors(
        containerColor = Color.Transparent,
        disabledContainerColor = Color(0xFF261D38)
      ),
      contentPadding = androidx.compose.foundation.layout.PaddingValues()
    ) {
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(52.dp)
          .background(
            if (prompt.isNotBlank() && !isGenerating) {
              Brush.horizontalGradient(
                listOf(Color(0xFF9333EA), Color(0xFF06B6D4))
              )
            } else {
              Brush.linearGradient(listOf(Color(0xFF2B2344), Color(0xFF201A33)))
            }
          ),
        contentAlignment = Alignment.Center
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.Center
        ) {
          Icon(
            imageVector = Icons.Default.AutoAwesome,
            contentDescription = null,
            tint = if (prompt.isNotBlank() && !isGenerating) Color.White else Color(0xFF64748B),
            modifier = Modifier.size(20.dp)
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = if (isGenerating) "Inachakata na Kuzalisha..." else "Tengeneza Sasa (AI Enhanced)",
            style = MaterialTheme.typography.labelLarge.copy(
              fontWeight = FontWeight.Bold,
              fontSize = 15.sp
            ),
            color = if (prompt.isNotBlank() && !isGenerating) Color.White else Color(0xFF64748B)
          )
        }
      }
    }
  }
}

@Composable
private fun AspectRatioCard(
  option: AspectRatioOption,
  isSelected: Boolean,
  modifier: Modifier = Modifier,
  onClick: () -> Unit
) {
  val borderColor by animateColorAsState(
    targetValue = if (isSelected) PrimaryNeonViolet else Color(0xFF282142),
    label = "ratio_border"
  )

  val bgColor by animateColorAsState(
    targetValue = if (isSelected) Color(0xFF271B42) else Color(0xFF141022),
    label = "ratio_bg"
  )

  Box(
    modifier = modifier
      .clip(RoundedCornerShape(14.dp))
      .background(bgColor)
      .border(
        width = if (isSelected) 1.5.dp else 1.dp,
        color = borderColor,
        shape = RoundedCornerShape(14.dp)
      )
      .clickable(onClick = onClick)
      .padding(vertical = 12.dp, horizontal = 6.dp)
      .testTag("aspect_ratio_${option.id.replace(":", "_")}"),
    contentAlignment = Alignment.Center
  ) {
    Column(
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.Center
    ) {
      Box(
        modifier = Modifier
          .padding(bottom = 8.dp)
          .size(
            width = when (option) {
              AspectRatioOption.SQUARE -> 24.dp
              AspectRatioOption.STORY -> 16.dp
              AspectRatioOption.LANDSCAPE -> 28.dp
            },
            height = when (option) {
              AspectRatioOption.SQUARE -> 24.dp
              AspectRatioOption.STORY -> 28.dp
              AspectRatioOption.LANDSCAPE -> 16.dp
            }
          )
          .border(
            width = 1.5.dp,
            color = if (isSelected) SecondaryCyan else Color(0xFF64748B),
            shape = RoundedCornerShape(3.dp)
          )
      )

      Text(
        text = option.label,
        style = MaterialTheme.typography.labelMedium.copy(
          fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
          fontSize = 13.sp
        ),
        color = if (isSelected) Color.White else Color(0xFFCBD5E1)
      )

      Spacer(modifier = Modifier.height(2.dp))

      Text(
        text = option.subLabel,
        style = MaterialTheme.typography.bodySmall.copy(fontSize = 9.sp),
        color = if (isSelected) SecondaryCyan else Color(0xFF94A3B8),
        textAlign = TextAlign.Center
      )
    }
  }
}
