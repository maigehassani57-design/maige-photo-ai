package com.example.ui.components

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.R
import com.example.model.EnhanceAction
import com.example.ui.theme.PrimaryNeonViolet
import com.example.ui.theme.SecondaryCyan

@Composable
fun ImageEnhancementTab(
  selectedImageUri: Uri?,
  sampleImageRes: Int?,
  onImageSelected: (Uri?) -> Unit,
  onSampleSelected: (Int) -> Unit,
  selectedActions: Set<EnhanceAction>,
  onToggleAction: (EnhanceAction) -> Unit,
  onEnhanceClick: () -> Unit,
  onOneTapMagicClick: () -> Unit,
  isGenerating: Boolean,
  modifier: Modifier = Modifier
) {
  val hasImage = selectedImageUri != null || sampleImageRes != null

  // Photo Picker launcher compliant with Google Play policy
  val photoPickerLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.PickVisualMedia(),
    onResult = { uri ->
      if (uri != null) {
        onImageSelected(uri)
      }
    }
  )

  Column(
    modifier = modifier
      .fillMaxWidth()
      .padding(horizontal = 20.dp, vertical = 10.dp)
      .testTag("image_enhancement_tab")
  ) {
    // Interactive Upload Card labeled 'Pakia Picha Yako Hapa'
    UploadCard(
      hasImage = hasImage,
      selectedImageUri = selectedImageUri,
      sampleImageRes = sampleImageRes,
      onUploadClick = {
        photoPickerLauncher.launch(
          PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
        )
      },
      onUseSampleClick = {
        onSampleSelected(R.drawable.img_enhanced_sample)
      }
    )

    Spacer(modifier = Modifier.height(16.dp))

    // Magic Auto-Enhance Hero Card: "Boresha kwa Mguso Mmoja"
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(18.dp))
        .background(
          Brush.horizontalGradient(
            listOf(Color(0xFF26123D), Color(0xFF131D38))
          )
        )
        .border(
          width = 1.5.dp,
          brush = Brush.horizontalGradient(
            listOf(Color(0xFFA855F7), Color(0xFF06B6D4))
          ),
          shape = RoundedCornerShape(18.dp)
        )
        .padding(14.dp)
        .testTag("magic_auto_enhance_card")
    ) {
      Column {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween,
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(32.dp)
                .clip(CircleShape)
                .background(Brush.linearGradient(listOf(Color(0xFF9333EA), Color(0xFF06B6D4)))),
              contentAlignment = Alignment.Center
            ) {
              Icon(
                imageVector = Icons.Default.AutoAwesome,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(18.dp)
              )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                text = "Boresha kwa Mguso Mmoja",
                style = MaterialTheme.typography.titleSmall.copy(
                  fontWeight = FontWeight.Bold,
                  fontSize = 14.sp
                ),
                color = Color.White
              )
              Text(
                text = "One-Tap Magic Auto-Enhance",
                style = MaterialTheme.typography.bodySmall.copy(fontSize = 10.sp),
                color = SecondaryCyan
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Text(
          text = "Inarekebisha mwangaza wa studio, inaondoa kelele (denoise), na kuongeza ukali mara moja bila kuhitaji kuandika maelezo yoyote.",
          style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
          color = Color(0xFFCBD5E1)
        )

        Spacer(modifier = Modifier.height(10.dp))

        Button(
          onClick = onOneTapMagicClick,
          enabled = hasImage && !isGenerating,
          modifier = Modifier
            .fillMaxWidth()
            .height(44.dp)
            .clip(RoundedCornerShape(12.dp))
            .testTag("btn_one_tap_magic"),
          colors = ButtonDefaults.buttonColors(
            containerColor = Color.Transparent,
            disabledContainerColor = Color(0xFF231A38)
          ),
          contentPadding = androidx.compose.foundation.layout.PaddingValues()
        ) {
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .height(44.dp)
              .background(
                if (hasImage && !isGenerating) {
                  Brush.horizontalGradient(
                    listOf(Color(0xFF9333EA), Color(0xFF2563EB))
                  )
                } else {
                  Brush.linearGradient(listOf(Color(0xFF2B2344), Color(0xFF1E1730)))
                }
              ),
            contentAlignment = Alignment.Center
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = Icons.Default.AutoAwesome,
                contentDescription = null,
                tint = if (hasImage && !isGenerating) Color.White else Color(0xFF64748B),
                modifier = Modifier.size(16.dp)
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = if (isGenerating) "Inaboresha kwa Mguso Mmoja..." else "Boresha kwa Mguso Mmoja (Bila Maelezo)",
                style = MaterialTheme.typography.labelMedium.copy(
                  fontWeight = FontWeight.Bold,
                  fontSize = 13.sp
                ),
                color = if (hasImage && !isGenerating) Color.White else Color(0xFF64748B)
              )
            }
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(16.dp))

    // Context-Aware Identity Protection Banner
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(14.dp))
        .background(Color(0xFF13172E))
        .border(1.dp, Color(0xFF1D4ED8).copy(alpha = 0.5f), RoundedCornerShape(14.dp))
        .padding(12.dp)
    ) {
      Row(verticalAlignment = Alignment.Top) {
        Icon(
          imageVector = Icons.Default.VerifiedUser,
          contentDescription = null,
          tint = Color(0xFF60A5FA),
          modifier = Modifier
            .size(20.dp)
            .padding(top = 2.dp)
        )
        Spacer(modifier = Modifier.width(10.dp))
        Column {
          Text(
            text = "Uchambuzi wa Sura & Utambulisho (Context-Aware)",
            style = MaterialTheme.typography.labelMedium.copy(
              fontWeight = FontWeight.Bold,
              fontSize = 12.sp
            ),
            color = Color(0xFF93C5FD)
          )
          Spacer(modifier = Modifier.height(2.dp))
          Text(
            text = "AI inalinda 100% sifa zote za sura, macho na ngozi ya mtu wakati unapobadilisha mandhari ya nyuma, mwangaza au nguo.",
            style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
            color = Color(0xFFBFDBFE)
          )
        }
      }
    }

    Spacer(modifier = Modifier.height(18.dp))

    // Quick Action Chips Header
    Row(
      verticalAlignment = Alignment.CenterVertically,
      modifier = Modifier.padding(bottom = 10.dp)
    ) {
      Icon(
        imageVector = Icons.Default.AutoFixHigh,
        contentDescription = null,
        tint = PrimaryNeonViolet,
        modifier = Modifier.size(18.dp)
      )
      Spacer(modifier = Modifier.width(6.dp))
      Text(
        text = "Marekebisho Mahususi (Custom Actions)",
        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
        color = Color.White
      )
    }

    // Grid of Quick action chips:
    // 'Boresha kwa Mguso Mmoja', 'Boresha Ubora (HD)', 'Badilisha Background', 'Nyoosha Sura', and 'Boresha Nguo'
    Column(
      verticalArrangement = Arrangement.spacedBy(8.dp),
      modifier = Modifier.fillMaxWidth()
    ) {
      EnhanceAction.entries.chunked(2).forEach { rowActions ->
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          rowActions.forEach { action ->
            val isSelected = selectedActions.contains(action)
            QuickActionChip(
              action = action,
              isSelected = isSelected,
              onClick = { onToggleAction(action) },
              modifier = Modifier.weight(1f)
            )
          }
          if (rowActions.size == 1) {
            Spacer(modifier = Modifier.weight(1f))
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(20.dp))

    // Primary Action Button: "Boresha Picha Sasa"
    val canEnhance = hasImage && selectedActions.isNotEmpty() && !isGenerating

    Button(
      onClick = onEnhanceClick,
      enabled = canEnhance,
      modifier = Modifier
        .fillMaxWidth()
        .height(52.dp)
        .clip(RoundedCornerShape(16.dp))
        .testTag("btn_enhance_image"),
      colors = ButtonDefaults.buttonColors(
        containerColor = Color.Transparent,
        disabledContainerColor = Color(0xFF261D38)
      ),
      contentPadding = androidx.compose.foundation.layout.PaddingValues()
    ) {
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(52.dp)
          .background(
            if (canEnhance) {
              Brush.horizontalGradient(
                listOf(Color(0xFF7C3AED), Color(0xFF0284C7))
              )
            } else {
              Brush.linearGradient(listOf(Color(0xFF2B2344), Color(0xFF201A33)))
            }
          ),
        contentAlignment = Alignment.Center
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.Center
        ) {
          Icon(
            imageVector = Icons.Default.AutoFixHigh,
            contentDescription = null,
            tint = if (canEnhance) Color.White else Color(0xFF64748B),
            modifier = Modifier.size(20.dp)
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = if (isGenerating) "AI Inachambua & Kuboresha..." else "Boresha Picha Sasa (Context-Aware)",
            style = MaterialTheme.typography.labelLarge.copy(
              fontWeight = FontWeight.Bold,
              fontSize = 15.sp
            ),
            color = if (canEnhance) Color.White else Color(0xFF64748B)
          )
        }
      }
    }
  }
}

@Composable
private fun UploadCard(
  hasImage: Boolean,
  selectedImageUri: Uri?,
  sampleImageRes: Int?,
  onUploadClick: () -> Unit,
  onUseSampleClick: () -> Unit
) {
  Box(
    modifier = Modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(20.dp))
      .background(Color(0xFF161224))
      .border(
        width = 1.5.dp,
        brush = Brush.linearGradient(
          if (hasImage) {
            listOf(PrimaryNeonViolet, SecondaryCyan)
          } else {
            listOf(Color(0xFF382F57), Color(0xFF231D38))
          }
        ),
        shape = RoundedCornerShape(20.dp)
      )
      .clickable(onClick = onUploadClick)
      .padding(18.dp)
      .testTag("interactive_upload_card"),
    contentAlignment = Alignment.Center
  ) {
    if (hasImage) {
      Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.fillMaxWidth()
      ) {
        Box(
          modifier = Modifier
            .size(130.dp)
            .clip(RoundedCornerShape(16.dp))
            .border(2.dp, PrimaryNeonViolet, RoundedCornerShape(16.dp))
        ) {
          if (selectedImageUri != null) {
            AsyncImage(
              model = selectedImageUri,
              contentDescription = "Picha Iliyochaguliwa",
              modifier = Modifier.size(130.dp),
              contentScale = ContentScale.Crop
            )
          } else if (sampleImageRes != null) {
            Image(
              painter = painterResource(id = sampleImageRes),
              contentDescription = "Picha ya Mfano",
              modifier = Modifier.size(130.dp),
              contentScale = ContentScale.Crop
            )
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Text(
          text = "Picha Imepakiwa Tayari!",
          style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
          color = SecondaryCyan
        )

        Spacer(modifier = Modifier.height(4.dp))

        Row(
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          OutlinedButton(
            onClick = onUploadClick,
            shape = RoundedCornerShape(12.dp),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 6.dp)
          ) {
            Icon(
              imageVector = Icons.Default.Refresh,
              contentDescription = null,
              tint = Color.White,
              modifier = Modifier.size(14.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text("Badilisha Picha", color = Color.White, style = MaterialTheme.typography.labelSmall)
          }
        }
      }
    } else {
      Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
        modifier = Modifier.padding(vertical = 12.dp)
      ) {
        // Upload Icon with glowing circle
        Box(
          modifier = Modifier
            .size(60.dp)
            .clip(CircleShape)
            .background(Color(0xFF261E3E))
            .border(1.dp, PrimaryNeonViolet.copy(alpha = 0.6f), CircleShape),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = Icons.Default.CloudUpload,
            contentDescription = "Pakia Picha",
            tint = SecondaryCyan,
            modifier = Modifier.size(32.dp)
          )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Label: 'Pakia Picha Yako Hapa'
        Text(
          text = "Pakia Picha Yako Hapa",
          style = MaterialTheme.typography.titleMedium.copy(
            fontWeight = FontWeight.Bold,
            fontSize = 17.sp
          ),
          color = Color.White,
          textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(6.dp))

        Text(
          text = "Gusa hapa kuchagua picha kutoka kwenye simu yako",
          style = MaterialTheme.typography.bodySmall,
          color = Color(0xFF94A3B8),
          textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Affordance to test with sample photo directly
        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(Color(0xFF221A3B))
            .clickable(onClick = onUseSampleClick)
            .padding(horizontal = 12.dp, vertical = 6.dp)
            .testTag("btn_use_sample_photo")
        ) {
          Text(
            text = "Au tumia picha ya mfano ↗",
            style = MaterialTheme.typography.labelSmall.copy(
              color = PrimaryNeonViolet,
              fontWeight = FontWeight.SemiBold
            )
          )
        }
      }
    }
  }
}

@Composable
private fun QuickActionChip(
  action: EnhanceAction,
  isSelected: Boolean,
  onClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  val borderColor by animateColorAsState(
    targetValue = if (isSelected) {
      if (action.isPrimaryMagic) SecondaryCyan else PrimaryNeonViolet
    } else {
      Color(0xFF2E254A)
    },
    label = "chip_border"
  )

  val bgColor by animateColorAsState(
    targetValue = if (isSelected) {
      if (action.isPrimaryMagic) Color(0xFF182845) else Color(0xFF2D1E4C)
    } else {
      Color(0xFF151024)
    },
    label = "chip_bg"
  )

  Box(
    modifier = modifier
      .clip(RoundedCornerShape(14.dp))
      .background(bgColor)
      .border(
        width = if (isSelected) 1.5.dp else 1.dp,
        color = borderColor,
        shape = RoundedCornerShape(14.dp)
      )
      .clickable(onClick = onClick)
      .padding(horizontal = 10.dp, vertical = 10.dp)
      .testTag("quick_action_${action.id}"),
    contentAlignment = Alignment.CenterStart
  ) {
    Row(
      verticalAlignment = Alignment.CenterVertically
    ) {
      Box(
        modifier = Modifier
          .size(32.dp)
          .clip(CircleShape)
          .background(
            if (isSelected) {
              if (action.isPrimaryMagic) Color(0xFF0284C7) else PrimaryNeonViolet
            } else {
              Color(0xFF22193A)
            }
          ),
        contentAlignment = Alignment.Center
      ) {
        Icon(
          imageVector = if (isSelected) Icons.Default.Check else action.icon,
          contentDescription = null,
          tint = if (isSelected) Color.White else SecondaryCyan,
          modifier = Modifier.size(16.dp)
        )
      }

      Spacer(modifier = Modifier.width(8.dp))

      Text(
        text = action.title,
        style = MaterialTheme.typography.labelMedium.copy(
          fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
          fontSize = 11.5.sp
        ),
        color = if (isSelected) Color.White else Color(0xFFE2E8F0)
      )
    }
  }
}
